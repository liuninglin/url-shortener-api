const productNames = ['policies', 'helper', 'how-to', 'faq', 'terms', 'privacy']

function getAllProductNames() {
  return productNames;
}
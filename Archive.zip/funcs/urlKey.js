const { customAlphabet } = require('nanoid');

const ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

async function getUrlKey(productName) {
    const nanoid = customAlphabet(ALPHABET, 8);
    let urlKey = nanoid();
    while ((await keyExists(productName + '/' + urlKey))) {
        urlKey = nanoId()
    }    
    return urlKey;
}

module.exports = { getUrlKey };